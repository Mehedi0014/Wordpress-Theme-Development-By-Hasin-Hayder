<?php
/**
 * Template Name: Test Template
 */
?>
<html>
<head>
    <?php get_header(); ?>
</head>
<body <?php body_class(); ?> >

<h1>
<?php the_title(); ?>
</h1>

<?php get_footer(); ?>
</body>
</html>
